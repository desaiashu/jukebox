//
//  Copyright (c) 2013-2015 Cédric Luthi. All rights reserved.
//

#import <Availability.h>

#import <XCDYouTubeKit/XCDYouTubeClient.h>
#import <XCDYouTubeKit/XCDYouTubeError.h>
#import <XCDYouTubeKit/XCDYouTubeOperation.h>
#import <XCDYouTubeKit/XCDYouTubeVideo.h>
#import <XCDYouTubeKit/XCDYouTubeVideoOperation.h>

#if TARGET_OS_IPHONE
#import <XCDYouTubeKit/XCDYouTubeVideoPlayerViewController.h>
#endif
